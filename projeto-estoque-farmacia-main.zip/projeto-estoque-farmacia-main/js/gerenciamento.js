async function getData(url) {
    const response = await fetch(url)
    const data = await response.json();
    return data;

}

async function postData(url, dados) {
    try {
        const response = await fetch(url,
            {
                method: "POST",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(dados)
            });
        const data = await response.json();
        return data;
    }
    catch (error) {
        console.error("Erro ao buscar dados", error);
    }

}


async function PesquisarRemedio() {
    const res = await getData('http://localhost:3000/api/remedios');
    let remediosPesquisa = document.getElementById("datalistPesquisa");

    if (res && res.length > 0) {
        res.forEach((remedio) => {
            let opcao = document.createElement("option");
            opcao.value = remedio.NomeMedicamento;
            opcao.text = remedio.NomeMedicamento;
            remediosPesquisa.append(opcao);
        });

    } else {
        console.log('Nenhum medicamento encontrado');
    }
}


async function EstoqueRemedios() {
    const res = await getData("http://localhost:3000/api/remedios");
    const estoque = await getData("http://localhost:3000/api/estoque");
    console.log(res);

    let remedios = document.getElementById("estoque-body");

    if ((res && res.length > 0) && (estoque && estoque.length > 0)) {
        res.forEach((remedio, indice) => {
            let tr = document.createElement("tr");
            tr.classList.add('remedio');
            tr.innerHTML = `
                <td>${remedio.NomeMedicamento}</td>
                <td>Remédio</td>
                <td>${remedio.Dosagem}</td>
                <td>${remedio.Unidade}</td>
                <td>${estoque[indice].Quantidade}</td>
            `;
            remedios.appendChild(tr);
        });
    } else {
        
        console.log('Nenhum medicamento encontrado');
    }
}
async function gerenciarEstoqueRemedios(acao, remedio) {
    // Verifica se os parâmetros são válidos
    if (!acao || (acao !== "adicionar" && acao !== "remover")) {
        console.error("Ação inválida. Use 'adicionar' ou 'remover'.");
        return;
    }

    if (!remedio || !remedio.NomeMedicamento || !remedio.Dosagem || !remedio.Unidade || typeof remedio.Quantidade !== "number") {
        console.error("Dados do remédio inválidos.");
        return;
    }

    const url = "http://localhost:3000/api/estoque";

    try {
        let response;

        if (acao === "adicionar") {
            response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(remedio),
            });
        } else if (acao === "remover") {
            response = await fetch(`${url}/${encodeURIComponent(remedio.NomeMedicamento)}`, {
                method: "DELETE",
            });
        }

        if (response.ok) {
            const result = await response.json();
            console.log(`${acao === "adicionar" ? "Adicionado" : "Removido"} com sucesso:`, result);
        } else {
            console.error("Erro ao realizar a ação no estoque:", response.status, response.statusText);
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
    }
}



async function gerenciarEstoqueEquipamentos(acao, equipamento) {
    // Verifica se os parâmetros são válidos
    if (!acao || (acao !== "adicionar" && acao !== "remover")) {
        console.error("Ação inválida. Use 'adicionar' ou 'remover'.");
        return;
    }

    if (!equipamento || !equipamento.NomeEquipamento || !equipamento.Unidade || typeof equipamento.Quantidade !== "number") {
        console.error("Dados do equipamento inválidos.");
        return;
    }

    const url = "http://localhost:3000/api/estoque";

    try {
        let response;

        if (acao === "adicionar") {
            response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(equipamento),
            });
        } else if (acao === "remover") {
            response = await fetch(`${url}/${encodeURIComponent(equipamento.NomeEquipamento)}`, {
                method: "DELETE",
            });
        }

        if (response.ok) {
            const result = await response.json();
            console.log(`${acao === "adicionar" ? "Adicionado" : "Removido"} com sucesso:`, result);
        } else {
            console.error("Erro ao realizar a ação no estoque:", response.status, response.statusText);
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
    }
}



async function gerenciarQuantidadeEstoqueEquipamentos(acao, equipamento, quantidade) {
    // Verifica se os parâmetros são válidos
    if (!acao || (acao !== "adicionar" && acao !== "remover")) {
        console.error("Ação inválida. Use 'adicionar' ou 'remover'.");
        return;
    }

    if (!equipamento || !equipamento.NomeEquipamento || !equipamento.Unidade || typeof quantidade !== "number" || quantidade <= 0) {
        console.error("Dados inválidos ou quantidade não especificada corretamente.");
        return;
    }

    const url = "http://localhost:3000/api/estoque";

    try {
        let response;

        if (acao === "adicionar") {
            const payload = {
                NomeEquipamento: equipamento.NomeEquipamento,
                Unidade: equipamento.Unidade,
                Quantidade: quantidade,
            };
            response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            });
        } else if (acao === "remover") {
            const payload = {
                NomeEquipamento: equipamento.NomeEquipamento,
                Quantidade: quantidade,
            };
            response = await fetch(url, {
                method: "PATCH", // Alterado para PATCH
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            });
        }

        if (response.ok) {
            const result = await response.json();
            console.log(`${acao === "adicionar" ? "Adicionado" : "Removido"} com sucesso:`, result);
        } else {
            console.error("Erro ao realizar a ação no estoque:", response.status, response.statusText);
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
    }
}


async function gerenciarQuantidadeEstoqueRemedios(acao, remedio, quantidade) {
    // Verifica se os parâmetros são válidos
    if (!acao || (acao !== "adicionar" && acao !== "remover")) {
        console.error("Ação inválida. Use 'adicionar' ou 'remover'.");
        return;
    }

    if (!remedio || !remedio.NomeMedicamento || !remedio.Dosagem || !remedio.Unidade || typeof quantidade !== "number" || quantidade <= 0) {
        console.error("Dados inválidos ou quantidade não especificada corretamente.");
        return;
    }

    const url = "http://localhost:3000/api/estoque";

    try {
        let response;

        if (acao === "adicionar") {
            const payload = {
                NomeMedicamento: remedio.NomeMedicamento,
                Dosagem: remedio.Dosagem,
                Unidade: remedio.Unidade,
                Quantidade: quantidade,
            };
            response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            });
        } else if (acao === "remover") {
            const payload = {
                NomeMedicamento: remedio.NomeMedicamento,
                Quantidade: quantidade,
            };
            response = await fetch(url, {
                method: "PATCH", // Alterado para PATCH
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            });
        }

        if (response.ok) {
            const result = await response.json();
            console.log(`${acao === "adicionar" ? "Adicionado" : "Removido"} com sucesso:`, result);
        } else {
            console.error("Erro ao realizar a ação no estoque:", response.status, response.statusText);
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
    }
}



PesquisarRemedio();
EstoqueRemedios()

